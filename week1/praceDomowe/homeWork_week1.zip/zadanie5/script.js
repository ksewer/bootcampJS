function getDate() {
	var date = new Date();
	console.log(date.getDate() + '.' + (date.getMonth() + 1) + '.' + date.getFullYear());
}
getDate();