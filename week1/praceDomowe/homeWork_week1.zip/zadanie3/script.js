function toBoolean(param) {
	if (param) {
		return true;
	}
	else return false;
}
console.log(toBoolean(20));
console.log(toBoolean(""));